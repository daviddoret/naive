"""naive: TODO: Add short description here"""

# Version of the naive package
__version__ = "0.1.0"

# TODO: Add module constants here
