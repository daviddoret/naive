naive: a starting project....
=============================

Project status
--------------
This is a far too early version, please wait for more information. 