from setuptools import setup

setup(name='naive',
      version='0.3',
      description='Testing installation of Package',
      url='#',
      author='David Doret',
      author_email='',
      license='MIT',
      packages=['naive'],
      zip_safe=False)
