

class CoercionError(Exception):
    """A user-defined error raised when a type coercion fails."""
    pass
