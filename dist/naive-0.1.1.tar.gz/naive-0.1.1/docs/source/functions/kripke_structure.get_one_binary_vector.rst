﻿kripke\_structure.get\_one\_binary\_vector
==========================================

.. currentmodule:: kripke_structure

.. autofunction:: get_one_binary_vector