﻿kripke\_structure.get\_set\_from\_range
=======================================

.. currentmodule:: kripke_structure

.. autofunction:: get_set_from_range