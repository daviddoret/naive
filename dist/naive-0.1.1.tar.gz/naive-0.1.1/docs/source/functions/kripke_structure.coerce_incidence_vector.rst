﻿kripke\_structure.coerce\_incidence\_vector
===========================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_incidence_vector