﻿kripke\_structure.get\_maxima
=============================

.. currentmodule:: kripke_structure

.. autofunction:: get_maxima