﻿kripke\_structure.get\_labels\_from\_state
==========================================

.. currentmodule:: kripke_structure

.. autofunction:: get_labels_from_state