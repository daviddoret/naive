﻿kripke\_structure.coerce\_state
===============================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_state