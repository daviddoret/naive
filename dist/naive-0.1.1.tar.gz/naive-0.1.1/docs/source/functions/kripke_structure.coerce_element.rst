﻿kripke\_structure.coerce\_element
=================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_element