﻿kripke\_structure.coerce\_atomic\_property\_set
===============================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_atomic_property_set