﻿kripke\_structure.sat\_phi\_and\_psi
====================================

.. currentmodule:: kripke_structure

.. autofunction:: sat_phi_and_psi