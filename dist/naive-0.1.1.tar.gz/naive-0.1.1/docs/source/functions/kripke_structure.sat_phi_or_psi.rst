﻿kripke\_structure.sat\_phi\_or\_psi
===================================

.. currentmodule:: kripke_structure

.. autofunction:: sat_phi_or_psi