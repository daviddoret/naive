﻿kripke\_structure.coerce\_set\_or\_iv\_type
===========================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_set_or_iv_type