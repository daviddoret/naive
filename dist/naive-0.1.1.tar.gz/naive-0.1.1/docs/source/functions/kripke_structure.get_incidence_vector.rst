﻿kripke\_structure.get\_incidence\_vector
========================================

.. currentmodule:: kripke_structure

.. autofunction:: get_incidence_vector