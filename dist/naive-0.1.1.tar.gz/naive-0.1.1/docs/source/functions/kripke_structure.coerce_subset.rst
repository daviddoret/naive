﻿kripke\_structure.coerce\_subset
================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_subset