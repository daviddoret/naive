﻿kripke\_structure.coerce\_atomic\_property
==========================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_atomic_property