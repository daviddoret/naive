

class NaiveWarning(UserWarning):
    """The generic category of warning issued by the **naive** library."""
    pass