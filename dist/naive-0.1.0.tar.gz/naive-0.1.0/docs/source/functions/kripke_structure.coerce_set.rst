﻿kripke\_structure.coerce\_set
=============================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_set