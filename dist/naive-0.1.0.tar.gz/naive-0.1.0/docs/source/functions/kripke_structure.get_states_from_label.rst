﻿kripke\_structure.get\_states\_from\_label
==========================================

.. currentmodule:: kripke_structure

.. autofunction:: get_states_from_label