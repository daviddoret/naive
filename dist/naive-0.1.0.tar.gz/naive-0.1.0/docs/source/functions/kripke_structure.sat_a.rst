﻿kripke\_structure.sat\_a
========================

.. currentmodule:: kripke_structure

.. autofunction:: sat_a