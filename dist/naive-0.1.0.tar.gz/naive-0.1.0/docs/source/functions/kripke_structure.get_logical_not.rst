﻿kripke\_structure.get\_logical\_not
===================================

.. currentmodule:: kripke_structure

.. autofunction:: get_logical_not