﻿kripke\_structure.is\_instance
==============================

.. currentmodule:: kripke_structure

.. autofunction:: is_instance