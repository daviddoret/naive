﻿kripke\_structure.coerce\_state\_set
====================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_state_set