﻿kripke\_structure.set\_cardinality
==================================

.. currentmodule:: kripke_structure

.. autofunction:: set_cardinality