﻿kripke\_structure.equals
========================

.. currentmodule:: kripke_structure

.. autofunction:: equals