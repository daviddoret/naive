﻿kripke\_structure.sat\_tt
=========================

.. currentmodule:: kripke_structure

.. autofunction:: sat_tt