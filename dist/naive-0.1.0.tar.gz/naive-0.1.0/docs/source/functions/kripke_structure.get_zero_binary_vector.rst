﻿kripke\_structure.get\_zero\_binary\_vector
===========================================

.. currentmodule:: kripke_structure

.. autofunction:: get_zero_binary_vector