﻿kripke\_structure.inverse
=========================

.. currentmodule:: kripke_structure

.. autofunction:: inverse