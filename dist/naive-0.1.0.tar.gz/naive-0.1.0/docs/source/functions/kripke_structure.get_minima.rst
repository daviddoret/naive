﻿kripke\_structure.get\_minima
=============================

.. currentmodule:: kripke_structure

.. autofunction:: get_minima