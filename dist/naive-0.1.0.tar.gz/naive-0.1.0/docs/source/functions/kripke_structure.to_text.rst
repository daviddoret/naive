﻿kripke\_structure.to\_text
==========================

.. currentmodule:: kripke_structure

.. autofunction:: to_text