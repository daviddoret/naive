﻿kripke\_structure.coerce\_kripke\_structure
===========================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_kripke_structure