﻿kripke\_structure.get\_state\_set
=================================

.. currentmodule:: kripke_structure

.. autofunction:: get_state_set