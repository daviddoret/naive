﻿kripke\_structure.flatten
=========================

.. currentmodule:: kripke_structure

.. autofunction:: flatten