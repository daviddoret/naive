﻿kripke\_structure.set\_element\_values\_from\_iterable
======================================================

.. currentmodule:: kripke_structure

.. autofunction:: set_element_values_from_iterable