﻿kripke\_structure.coerce\_binary\_value
=======================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_binary_value