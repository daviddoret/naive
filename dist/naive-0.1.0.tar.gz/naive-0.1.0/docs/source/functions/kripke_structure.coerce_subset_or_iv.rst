﻿kripke\_structure.coerce\_subset\_or\_iv
========================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_subset_or_iv