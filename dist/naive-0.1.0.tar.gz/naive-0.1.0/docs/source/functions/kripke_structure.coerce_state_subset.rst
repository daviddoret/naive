﻿kripke\_structure.coerce\_state\_subset
=======================================

.. currentmodule:: kripke_structure

.. autofunction:: coerce_state_subset