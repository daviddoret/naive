﻿kripke\_structure.sat\_not\_phi
===============================

.. currentmodule:: kripke_structure

.. autofunction:: sat_not_phi