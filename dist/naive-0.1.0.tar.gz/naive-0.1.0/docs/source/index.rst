Welcome to Naive's documentation!
===================================

**Naive** (/naɪˈiːv/) is a model checking Python library. Its salient characteristics are:
* Instead of

Check out the :doc:`usage` section for further information, including
how to :ref:`installation` the project.

.. note::

   This project is under active development.

Contents
--------

.. toctree::

   usage
   kripke_structure_classes
   kripke_structure_section
