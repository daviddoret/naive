﻿kripke\_structure.KripkeStructure
=================================

.. currentmodule:: kripke_structure

.. autoclass:: KripkeStructure

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~KripkeStructure.__init__
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~KripkeStructure.ap
      ~KripkeStructure.i
      ~KripkeStructure.lm
      ~KripkeStructure.s
      ~KripkeStructure.tm
   
   