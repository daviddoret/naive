

class ForbiddenOperationError(Exception):
    """A user-defined error raised to prevent operations that must be forbidden by design."""
    pass
