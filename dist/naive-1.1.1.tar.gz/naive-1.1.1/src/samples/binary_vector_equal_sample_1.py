"""Binary Vector Equality Operator - Code Sample 1

This code sample illustrates the basic usage of the binary vector equality operator"""

print(tl.bv_equal_bv([1, 0, 1, 0, 0], [1, 0, 1, 0, 0]))

