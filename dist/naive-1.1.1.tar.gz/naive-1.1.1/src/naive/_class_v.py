from _class_variable import Variable


"""A shorthand alias for class :class:`Variable`."""
V = Variable
