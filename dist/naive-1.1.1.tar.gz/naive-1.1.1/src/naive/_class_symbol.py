from _class_persisting_representable import PersistingRepresentable


class Symbol(PersistingRepresentable):
    """A mathematical object represented by a symbol."""
    pass
