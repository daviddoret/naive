

class NaiveError(Exception):
    """The generic exception type raised by the **naive** library."""
    pass
