"""naive: TODO: Add short description here"""

# Version of the naive package
__version__ = "0.1.2"

# Source: https://stackoverflow.com/questions/67085041/how-to-specify-version-in-only-one-place-when-using-pyproject-toml
#import importlib.metadata
#__version__ = importlib.metadata.version("naive")