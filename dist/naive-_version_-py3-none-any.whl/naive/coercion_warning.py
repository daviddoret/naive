

class CoercionWarning(UserWarning):
    """A user-defined warning sent when aggressive type coercion was necessary."""
    pass