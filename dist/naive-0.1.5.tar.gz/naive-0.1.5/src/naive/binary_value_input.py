import typing

from .binary_value import BinaryValue

"""This :type:`typing.TypeVar` lists allowed types for implicit type coercion."""
BinaryValueInput = typing.TypeVar(
    'BinaryValueInput',
    BinaryValue,
    bool,
    int
)